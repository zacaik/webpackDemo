"use strict";(self.webpackChunkwebpack_dev_server=self.webpackChunkwebpack_dev_server||[]).push([["main"],{"./src/index.js":
/*!**********************!*\
  !*** ./src/index.js ***!
  \**********************/(s,e,c)=>{var r=c(/*! ./math */"./src/math.js"),n=(c(/*! ./index.css */"./src/index.css"),(0,r.sum)(1,2));console.log(n)},"./src/math.js":
/*!*********************!*\
  !*** ./src/math.js ***!
  \*********************/(s,e,c)=>{function r(s,e){return s+e}c.d(e,{sum:()=>r})},"./src/index.css":
/*!***********************!*\
  !*** ./src/index.css ***!
  \***********************/()=>{}},s=>{var e;e="./src/index.js",s(s.s=e)}]);
//# sourceMappingURL=main.js.map